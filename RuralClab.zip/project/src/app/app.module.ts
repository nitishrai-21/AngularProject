import { CarouselModule } from 'ngx-bootstrap';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing/app-routing.module';
import {MatToolbarModule} from '@angular/material/toolbar';
import { MatTabsModule, MatSidenavModule } from '@angular/material';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule, MatIconModule } from '@angular/material';
import { MatListModule } from '@angular/material/list';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import {FlexLayoutModule} from '@angular/flex-layout';
import { ReactiveFormsModule } from '@angular/forms';
// import { Ng2CarouselamosModule } from 'ng2-carouselamos';

import { MaterialModule } from './Modules/material.module';




import { AppComponent } from './app.component';
import {RegistrationComponent } from './registration/registration.component';
import { ServicesMenuComponent } from './services-menu/services-menu.component';
import 'hammerjs';
import { NavbarComponent } from './navbar/navbar.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CarousalComponent } from './carousal/carousal.component';






@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    NavbarComponent,
    SidenavComponent,
    HomeComponent,
    AboutComponent,
    LoginComponent,
    HeaderComponent,
    FooterComponent,
    CarousalComponent,
    ServicesMenuComponent
  ],
  imports: [
    BrowserModule,
    FlexLayoutModule,
    MatDialogModule,
    MatCardModule,
    MatToolbarModule,
    MatTabsModule,
    MatSidenavModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    // Ng2CarouselamosModule,
    MaterialModule,
    CarouselModule.forRoot(),
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
