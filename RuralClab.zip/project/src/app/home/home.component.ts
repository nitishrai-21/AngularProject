import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef} from '@angular/material';
import { ServicesMenuComponent } from '../services-menu/services-menu.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(public dialog: MatDialog) { }
  openServicesTab() {
    this.dialog.open(ServicesMenuComponent,{width: '500px', height: 'max-content', panelClass: 'services-dialog-container'});
  }

  ngOnInit() {
  }

}
