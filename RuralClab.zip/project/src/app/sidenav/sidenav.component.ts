import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {MatDialog, MatDialogRef} from '@angular/material';
import { RegistrationComponent} from '../registration/registration.component'

declare const window: any;
@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent implements OnInit {
  @Output() public sidenavClose=new EventEmitter();

  constructor(public dialog: MatDialog) { }

  openLoginForm() {
    this.dialog.open(RegistrationComponent,{width: '600px', height:'400px'});
  }

  ngOnInit() {
  }

  public onSidenavClose = () =>{
    this.sidenavClose.emit();
  }


  
}
