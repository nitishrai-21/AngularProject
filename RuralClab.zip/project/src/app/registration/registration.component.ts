import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validator, Validators } from '@angular/forms';
import { RegisterModel } from '../Shared/registration';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  user: RegisterModel= new RegisterModel();
  regsterForm: FormGroup;
  
  constructor( private formBuilder: FormBuilder) {}

  ngOnInit() {
    this.regsterForm= this.formBuilder.group({
      'name': [this.user.name,[Validators.required]],
      'password': [this.user.password,[Validators.required]],
      'confirm': [this.user.confirm,[Validators.required]],
      'phone': [this.user.phone,[Validators.required]],
      'email': [this.user.email,[Validators.required, Validators.email]]
    });
  }

}
