import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carousal',
  templateUrl: './carousal.component.html',
  styleUrls: ['./carousal.component.css']
})
export class CarousalComponent implements OnInit {

  // items: Array<any> =[];
  constructor() { 
    // this.items=[
    //   { name: 'assets/images/spa.png'},
    //   { name: 'assets/images/spa.png'},
    //   { name: 'assets/images/spa.png'},
    //   { name: 'assets/images/spa.png'},
    //   { name: 'assets/images/spa.png'},
    //   { name: 'assets/images/spa.png'},
    //   { name: 'assets/images/spa.png'},
    //   { name: 'assets/images/spa.png'},
      
    // ];
  }

  ngOnInit() {
  }

}
