export class RegisterModel{
    name: string;
    password: string;
    confirm : string;
    phone : number;
    email: string;
}
