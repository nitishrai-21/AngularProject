import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { PageEvent } from '@angular/material';
import { HostListener, Inject } from "@angular/core";
import {MatDialog, MatDialogRef} from '@angular/material';
import { RegistrationComponent} from '../registration/registration.component'

declare const window: any;
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  @Output() public sidenavToggle=new EventEmitter();
  constructor(public dialog: MatDialog) { }

  openLoginForm() {
    this.dialog.open(RegistrationComponent,{width: '600px', height:'400px'});
  }

  ngOnInit() {
  }

  public onToggleSidenav=()=>{
    this.sidenavToggle.emit();
  }

  @HostListener("window:scroll", [])
  onWindowScroll() {

    const number = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop ;
    if (number > 100) {
      document.getElementById("nav").style.background = "#673ab7";
      var links = document.getElementsByTagName("a");
      for(var i=0;i<links.length;i++)
      {
          links[i].style.color = "white";  
      }  
    } else {
      document.getElementById("nav").style.background = "transparent";
      var links = document.getElementsByTagName("a");
      for(var i=0;i<links.length;i++)
      {
          links[i].style.color = "white";  
      }  
    }
  }

}

